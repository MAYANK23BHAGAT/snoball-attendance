// =====================================================
// API LAYER FOR THE INSTALLABLE APP
// Add this as a new file (api) in your Apps Script project.
// It reuses getState, markLogin and markLogout from Code.gs.
// =====================================================

// Paste the OAuth Client ID you create in Google Cloud Console (see SETUP.md).
const GOOGLE_CLIENT_ID = 'PASTE_CLIENT_ID.apps.googleusercontent.com';
const ALLOWED_DOMAIN = 'owledmedia.com';
const SESSION_DAYS = 30;

// Set per request. whoAmI_ in Code.gs reads this before falling back to Session.
let API_EMAIL = '';

// Run this once from the editor so Google asks you to approve the external request permission.
function authorizeOnce() {
  UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=test', { muteHttpExceptions: true });
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const action = String(body.action || '');

    if (action === 'auth') {
      API_EMAIL = verifyIdToken_(body.idToken);
      const me = whoAmI_();
      return json_({ ok: true, data: { session: makeSession_(me.email), name: me.name } });
    }

    API_EMAIL = readSession_(body.session);
    if (!API_EMAIL) throw authError_('Session expired. Please sign in again.');

    let data;
    if (action === 'state') data = getState();
    else if (action === 'login') data = markLogin(geoFrom_(body.geo));
    else if (action === 'logout') data = markLogout(body.note, geoFrom_(body.geo));
    else throw new Error('Unknown action.');
    return json_({ ok: true, data: data });
  } catch (err) {
    return json_({ ok: false, error: String(err && err.message ? err.message : err), code: err && err.code ? err.code : '' });
  }
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function authError_(msg) {
  const e = new Error(msg);
  e.code = 'AUTH';
  return e;
}

// Turns the location sent by the app into the shape Code.gs already understands.
function geoFrom_(g) {
  if (g && g.status === 'ok') {
    const lat = Number(g.lat), lng = Number(g.lng), acc = Number(g.acc);
    if (isFinite(lat) && isFinite(lng) && Math.abs(lat) <= 90 && Math.abs(lng) <= 180) {
      return { status: 'ok', lat: lat, lng: lng, acc: isFinite(acc) ? acc : 0 };
    }
    return { status: 'unavailable' };
  }
  if (g && g.status === 'unavailable') return { status: 'unavailable' };
  return { status: 'denied' };
}

// Checks the Google sign-in token and returns the verified owledmedia.com email.
function verifyIdToken_(idToken) {
  if (!idToken) throw authError_('Please sign in again.');
  const res = UrlFetchApp.fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(idToken),
                                { muteHttpExceptions: true });
  if (res.getResponseCode() !== 200) throw authError_('Sign in failed. Please try again.');
  const t = JSON.parse(res.getContentText());
  if (t.aud !== GOOGLE_CLIENT_ID) throw authError_('Sign in failed (app mismatch).');
  if (String(t.email_verified) !== 'true') throw authError_('Your Google email is not verified.');
  if (String(t.hd || '').toLowerCase() !== ALLOWED_DOMAIN) throw authError_('Please sign in with your @' + ALLOWED_DOMAIN + ' account.');
  if (Number(t.exp) * 1000 < Date.now()) throw authError_('Sign in expired. Please try again.');
  return String(t.email).toLowerCase();
}

// ---------- Signed session so people stay logged in ----------

function secret_() {
  const p = PropertiesService.getScriptProperties();
  let s = p.getProperty('SESSION_SECRET');
  if (!s) {
    s = Utilities.getUuid() + Utilities.getUuid();
    p.setProperty('SESSION_SECRET', s);
  }
  return s;
}

function sign_(payload) {
  return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(payload, secret_()));
}

function makeSession_(email) {
  const payload = email + '|' + (Date.now() + SESSION_DAYS * 86400000);
  return Utilities.base64EncodeWebSafe(payload) + '.' + sign_(payload);
}

function readSession_(s) {
  try {
    const parts = String(s || '').split('.');
    if (parts.length !== 2) return '';
    const payload = Utilities.newBlob(Utilities.base64DecodeWebSafe(parts[0])).getDataAsString();
    if (sign_(payload) !== parts[1]) return '';
    const bits = payload.split('|');
    if (Number(bits[1]) < Date.now()) return '';
    return String(bits[0]).toLowerCase();
  } catch (e) {
    return '';
  }
}

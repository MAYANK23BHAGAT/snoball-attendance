const SS_ID = '1j5X5Oyd809pfbht-ygHVk9WDQvhJt7zcPLuJJBezDGw';
const TZ = 'Asia/Kolkata';
const LOG = 'Attendance Log';
const CFG = 'Config';
const TEAM = 'Team';
const LOCVIEW = 'Location View';
const NOTE_AFTER_MIN = 30;

// ---- Location settings ----
// 1) Your GitHub Pages link to location.html
const GEO_PAGE_URL = 'https://mayank23bhagat.github.io/snoball-location/location.html';
// 2) The /exec link of the PUBLIC deployment (Execute as Me, access Anyone). Paste yours between the quotes.
const GEO_API_URL = 'https://script.google.com/macros/s/AKfycbxywqsB-Rg2w503EGZlYFyvy7PKr119D0RGnKJeUGXRtHceIW6wi2t84oBGzkRmSKRU3Q/exec';
// true = people cannot log in or out unless they share location
const REQUIRE_LOCATION = false;
// Office coordinates: right click the office on Google Maps and click the numbers to copy them.
// Leave both at 0 to skip the office check. Place names are still recorded.
const OFFICE_LAT = 0;
const OFFICE_LNG = 0;
const OFFICE_RADIUS_M = 200;
const LOW_ACCURACY_M = 300;

// ---- Attendance Log column layout ----
// A to M : original columns
// N to S : Login Lat, Long, Accuracy, Location, Address, Map
// T to Y : Logout Lat, Long, Accuracy, Location, Address, Map
// Z to AB: Time Worked, Shift Progress, Overtime Time
const LOC_LOGIN_COL = 14;
const LOC_LOGOUT_COL = 20;
const LOC_WIDTH = 6;
const DISP_COL = 26;
const LAST_COL = 28;

function ss_() {
  return SpreadsheetApp.openById(SS_ID);
}

// Adds any missing columns and makes sure they do not inherit the OT Status dropdown from column M.
function ensureCols_(sheet) {
  const max = sheet.getMaxColumns();
  if (max < LAST_COL) {
    sheet.insertColumnsAfter(max, LAST_COL - max);
    sheet.getRange(1, max + 1, sheet.getMaxRows(), LAST_COL - max).clearDataValidations();
  }
}

// =====================================================
// ONE TIME SETUP (run from the editor)
// Your sheet already has the headers and formatting, so you only need backfillLocations().
// =====================================================

function setupLocationColumns() {
  const sheet = ss_().getSheetByName(LOG);
  ensureCols_(sheet);
  const heads = ['📍 In · Lat', '📍 In · Long', '🎯 In · Accuracy (m)', '📍 Login Location', '🧭 Login Address', '🗺️ Login Map',
                 '📍 Out · Lat', '📍 Out · Long', '🎯 Out · Accuracy (m)', '📍 Logout Location', '🧭 Logout Address', '🗺️ Logout Map',
                 '⏱ Time Worked', '📊 Shift Progress', '🔥 Overtime Time'];
  sheet.getRange(1, LOC_LOGIN_COL, 1, heads.length).setValues([heads]);
  sheet.getRange(2, LOC_LOGIN_COL, Math.max(1, sheet.getMaxRows() - 1), LAST_COL - LOC_LOGIN_COL + 1).clearDataValidations();
}

// Run once: turns saved coordinates into place names, addresses and map links for rows that have
// numbers but blank location columns, and fills the readable time columns.
function backfillLocations() {
  const sheet = ss_().getSheetByName(LOG);
  ensureCols_(sheet);
  const last = sheet.getLastRow();
  if (last < 2) return;
  const vals = sheet.getRange(2, 1, last - 1, DISP_COL + 2).getValues();
  vals.forEach(function (r, i) {
    const row = i + 2;
    const key = keyOf_(r[0]);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(key)) return;
    const dayMode = dayModeFor_(new Date(key + 'T12:00:00+05:30'));

    const inLat = r[LOC_LOGIN_COL - 1];
    if (typeof inLat === 'number' && !r[LOC_LOGIN_COL + 2]) {
      const geo = { status: 'ok', lat: inLat, lng: r[LOC_LOGIN_COL], acc: r[LOC_LOGIN_COL + 1] };
      sheet.getRange(row, LOC_LOGIN_COL, 1, LOC_WIDTH).setValues([locCells_(geo, dayMode)]);
    }
    const outLat = r[LOC_LOGOUT_COL - 1];
    if (typeof outLat === 'number' && !r[LOC_LOGOUT_COL + 2]) {
      const geo = { status: 'ok', lat: outLat, lng: r[LOC_LOGOUT_COL], acc: r[LOC_LOGOUT_COL + 1] };
      sheet.getRange(row, LOC_LOGOUT_COL, 1, LOC_WIDTH).setValues([locCells_(geo, dayMode)]);
    }
    if (r[4] && r[5] !== '' && !r[DISP_COL - 1]) {
      sheet.getRange(row, DISP_COL, 1, 3).setValues([displayCells_(Number(r[5]), Number(r[6]) || 0)]);
    }
  });
}

function createTrigger() {
  ScriptApp.getProjectTriggers().forEach(t => {
    if (t.getHandlerFunction() === 'flagMissingLogouts') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('flagMissingLogouts').timeBased().atHour(1).everyDays(1).inTimezone(TZ).create();
}

// Builds the Location View tab: everyone's login and logout place for a chosen date.
function setupLocationView() {
  const ss = ss_();
  let sh = ss.getSheetByName(LOCVIEW);
  if (!sh) sh = ss.insertSheet(LOCVIEW);
  sh.clear();
  sh.clearConditionalFormatRules();

  const src = "'" + LOG + "'!A2:Y";
  const q = function (cols) {
    return '=IFERROR(QUERY(' + src + ', "select ' + cols +
           ' where A = \'"&TEXT($B$2,"yyyy-mm-dd")&"\' order by D, C", 0), "")';
  };
  const link = function (lat, lng) {
    return '=ARRAYFORMULA(IF(' + lat + '5:' + lat + '200="","",HYPERLINK("https://www.google.com/maps?q="&' +
           lat + '5:' + lat + '200&","&' + lng + '5:' + lng + '200,"Open map")))';
  };

  sh.getRange('A1').setValue('Location View').setFontSize(16).setFontWeight('bold');
  sh.getRange('A2').setValue('Date').setFontWeight('bold');
  sh.getRange('B2').setFormula('=TODAY()').setNumberFormat('ddd, dd mmm yyyy').setBackground('#fff9c4');
  sh.getRange('C2').setValue('Type any other date in the yellow cell to see that day.').setFontColor('#64748b');
  sh.getRange('A3').setFormula('=IF(COUNTA(A5:A200)=0,"No entries for this date",COUNTA(A5:A200)&" people logged in")');

  const heads = ['Name', 'Mode', 'Login time', 'Login location', 'Login address', 'Login map',
                 'Logout time', 'Logout location', 'Logout address', 'Logout map',
                 '', 'Login lat', 'Login long', 'Logout lat', 'Logout long'];
  sh.getRange(4, 1, 1, heads.length).setValues([heads])
    .setFontWeight('bold').setBackground('#312e81').setFontColor('#ffffff');

  sh.getRange('A5').setFormula(q('C, K, D, Q, R'));
  sh.getRange('G5').setFormula(q('E, W, X'));
  sh.getRange('L5').setFormula(q('N, O, T, U'));
  sh.getRange('F5').setFormula(link('L', 'M'));
  sh.getRange('J5').setFormula(link('N', 'O'));

  sh.getRange('C5:C200').setNumberFormat('hh:mm:ss AM/PM');
  sh.getRange('G5:G200').setNumberFormat('hh:mm:ss AM/PM');
  sh.hideColumns(11, 5);
  sh.setFrozenRows(4);
  sh.setColumnWidth(1, 150);
  sh.setColumnWidth(2, 90);
  sh.setColumnWidth(3, 90);
  sh.setColumnWidth(4, 230); 
  sh.setColumnWidth(5, 320);
  sh.setColumnWidth(6, 90);
  sh.setColumnWidth(7, 90);
  sh.setColumnWidth(8, 230);
  sh.setColumnWidth(9, 320);
  sh.setColumnWidth(10, 90);

  const rules = [];
  ['D5:D200', 'H5:H200'].forEach(function (a) {
    const r = sh.getRange(a);
    [['Outside', '#fecaca'], ['not shared', '#fde68a'], ['unavailable', '#fde68a'], ['low accuracy', '#fef3c7'], ['At office', '#dcfce7']]
      .forEach(function (p) {
        rules.push(SpreadsheetApp.newConditionalFormatRule().whenTextContains(p[0]).setBackground(p[1]).setRanges([r]).build());
      });
  });
  sh.setConditionalFormatRules(rules);
}

// =====================================================
// WEB APP
// =====================================================

function doGet(e) {
  // The public deployment receives coordinates from location.html here.
  if (e && e.parameter && e.parameter.action === 'geo') return handleGeo_(e);

  let page;
  try {
    page = HtmlService.createHtmlOutputFromFile('index');
  } catch (err) {
    page = HtmlService.createHtmlOutputFromFile('Index');
  }
  return page
    .setTitle('Snoball Attendance')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ---------- Location hand-off ----------

const TOKEN_RE = /^[0-9a-f-]{36}$/;

function handleGeo_(e) {
  const out = function (t) { return ContentService.createTextOutput(t); };
  const p = e.parameter || {};
  const token = String(p.token || '');
  if (!TOKEN_RE.test(token)) return out('invalid');
  const cache = CacheService.getScriptCache();
  const raw = cache.get('geo_' + token);
  if (!raw) return out('expired');
  const rec = JSON.parse(raw);

  const status = String(p.status || '');
  if (status === 'ok') {
    const lat = Number(p.lat), lng = Number(p.lng), acc = Number(p.acc);
    if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return out('invalid');
    rec.status = 'ok'; rec.lat = lat; rec.lng = lng; rec.acc = isFinite(acc) ? acc : 0;
  } else if (status === 'denied' || status === 'unavailable') {
    rec.status = status;
  } else {
    return out('invalid');
  }
  cache.put('geo_' + token, JSON.stringify(rec), 900);
  return out('ok');
}

// Called by the attendance page. Creates a one-time code tied to the signed-in person.
function createGeoToken() {
  if (GEO_API_URL.indexOf('PASTE_') === 0 || GEO_PAGE_URL.indexOf('YOURNAME') >= 0) {
    throw new Error('Location setup is not finished yet. Ask Champs to set GEO_PAGE_URL and GEO_API_URL.');
  }
  const me = whoAmI_();
  const token = Utilities.getUuid();
  CacheService.getScriptCache().put('geo_' + token, JSON.stringify({ email: me.email, status: 'pending' }), 900);
  return { token: token, url: GEO_PAGE_URL + '?token=' + token + '&api=' + encodeURIComponent(GEO_API_URL) };
}

function readGeo_(token, email) {
  if (token && typeof token === 'object') return token.status ? token : null;
  if (!TOKEN_RE.test(String(token || ''))) return null;
  const raw = CacheService.getScriptCache().get('geo_' + token);
  if (!raw) return null;
  const rec = JSON.parse(raw);
  return rec.email === email ? rec : null;
}

function removeGeo_(token) {
  if (TOKEN_RE.test(String(token || ''))) CacheService.getScriptCache().remove('geo_' + token);
}

function getGeoStatus(token) {
  const me = whoAmI_();
  const rec = readGeo_(token, me.email);
  return { status: rec ? rec.status : 'none' };
}

// ---------- Basics ----------

function cfgValue_(row) {
  return Number(ss_().getSheetByName(CFG).getRange(row, 2).getValue());
}

function whoAmI_() {
  const email = (API_EMAIL || Session.getActiveUser().getEmail() || '').toLowerCase();
  if (!email) throw new Error('Could not read your email. Open the link while signed in to your OWLED account.');
  const team = ss_().getSheetByName(TEAM).getDataRange().getValues();
  for (let i = 1; i < team.length; i++) {
    if (String(team[i][0]).toLowerCase().trim() === email) return { email: email, name: team[i][1] };
  }
  throw new Error('Your email (' + email + ') is not on the Team sheet. Ask Champs to add you.');
}

function todayKey_() {
  return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd');
}

function keyOf_(v) {
  return Object.prototype.toString.call(v) === '[object Date]'
    ? Utilities.formatDate(v, TZ, 'yyyy-MM-dd')
    : String(v);
}

function minutesOfDay_(d) {
  return Number(Utilities.formatDate(d, TZ, 'H')) * 60 + Number(Utilities.formatDate(d, TZ, 'm'));
}

function findRow_(sheet, key, email) {
  const last = sheet.getLastRow();
  if (last < 2) return -1;
  const vals = sheet.getRange(2, 1, last - 1, 2).getValues();
  for (let i = vals.length - 1; i >= 0; i--) {
    if (keyOf_(vals[i][0]) === key && String(vals[i][1]).toLowerCase() === email) return i + 2;
  }
  return -1;
}

function fmt_(d) {
  return d ? Utilities.formatDate(new Date(d), TZ, 'hh:mm a') : '';
}

// What the calendar says for a given moment: WFH on the Config WFH day, otherwise Office.
function dayModeFor_(date) {
  const dayNum = Number(Utilities.formatDate(date, TZ, 'u'));
  return dayNum === cfgValue_(6) ? 'WFH' : 'Office';
}

// Work Mode shown in the log. Saturday stays WFH. On other days it is Office inside the
// office radius and WFH outside. Without a location or office coordinates it follows the day rule.
function modeFor_(geo, dayMode) {
  if (dayMode === 'WFH') return 'WFH';
  if (geo && geo.status === 'ok' && OFFICE_LAT && OFFICE_LNG) {
    const d = distanceM_(Number(geo.lat), Number(geo.lng), OFFICE_LAT, OFFICE_LNG);
    return d <= OFFICE_RADIUS_M ? 'Office' : 'WFH';
  }
  return dayMode;
}

// ---------- Readable time helpers ----------

// 8.75 -> "8 hr 45 min", 1 -> "1 hr", 0.5 -> "30 min"
function hm_(hours) {
  const total = Math.round(Number(hours) * 60);
  const h = Math.floor(total / 60), m = total % 60;
  if (h && m) return h + ' hr ' + m + ' min';
  if (h) return h + ' hr';
  return m + ' min';
}

// 10 block progress bar, e.g. ▰▰▰▰▰▰▰▰▰▱ 97%
function bar_(hours, std) {
  const pct = Math.max(0, Math.min(1, hours / std));
  const filled = Math.round(pct * 10);
  return '▰'.repeat(filled) + '▱'.repeat(10 - filled) + ' ' + Math.round(pct * 100) + '%';
}

// Returns 3 cells: time worked, shift progress, overtime
function displayCells_(hours, overtime) {
  const std = cfgValue_(5) || 9;
  const worked = (hours >= std ? '✅ ' : '⏱ ') + hm_(hours);
  const ot = overtime > 0 ? '🔥 +' + hm_(overtime) : '-';
  return [worked, bar_(hours, std), ot];
}

// ---------- Location helpers ----------

function distanceM_(lat1, lng1, lat2, lng2) {
  const R = 6371000, rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad, dLng = (lng2 - lng1) * rad;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
            Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Looks up the place for a point. Returns { address, place }.
// place is a short name such as "Indiranagar, Bengaluru". Both are empty if the lookup fails.
function placeOf_(lat, lng) {
  const out = { address: '', place: '' };
  try {
    const res = Maps.newGeocoder().setLanguage('en').reverseGeocode(lat, lng);
    if (res && res.status === 'OK' && res.results && res.results.length) {
      const r = res.results[0];
      out.address = r.formatted_address || '';
      const pick = function (type) {
        const comps = r.address_components || [];
        for (let i = 0; i < comps.length; i++) {
          if (comps[i].types.indexOf(type) >= 0) return comps[i].long_name;
        }
        return '';
      };
      const area = pick('sublocality_level_1') || pick('sublocality') || pick('neighborhood');
      const city = pick('locality') || pick('administrative_area_level_2');
      out.place = [area, city].filter(String).join(', ');
    }
  } catch (e) {}
  return out;
}

// Returns 6 cells: lat, long, accuracy, location label, full address, clickable map link
// dayMode is the calendar rule (WFH on Saturday, otherwise Office).
function locCells_(geo, dayMode) {
  const none = function (label) { return ['', '', '', label, '', '']; };
  if (!geo || geo.status !== 'ok') {
    return none(geo && geo.status === 'unavailable' ? 'Location unavailable' : 'Location not shared');
  }
  const lat = Number(geo.lat), lng = Number(geo.lng), acc = Math.round(Number(geo.acc) || 0);
  if (!isFinite(lat) || !isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return none('Location unavailable');

  const where = placeOf_(lat, lng);
  let tag = '';
  if (dayMode === 'WFH') {
    tag = 'WFH';
  } else if (OFFICE_LAT && OFFICE_LNG) {
    const d = distanceM_(lat, lng, OFFICE_LAT, OFFICE_LNG);
    tag = d <= OFFICE_RADIUS_M ? 'At office' : 'Outside office (' + Math.round(d) + ' m away)';
  }
  let label = [tag, where.place].filter(String).join(' · ');
  if (!label) label = 'Location captured';
  if (acc > LOW_ACCURACY_M) label += ', low accuracy';

  return [
    lat, lng, acc, label,
    where.address,
    '=HYPERLINK("https://www.google.com/maps?q=' + lat + ',' + lng + '","Open map")'
  ];
}

// ---------- Web app actions ----------

function getState() {
  const me = whoAmI_();
  const sheet = ss_().getSheetByName(LOG);
  ensureCols_(sheet);
  const row = findRow_(sheet, todayKey_(), me.email);
  const out = { name: me.name, state: 'none', login: '', logout: '', hours: '', hoursText: '', flags: '', locIn: '', locOut: '' };
  if (row > 0) {
    const r = sheet.getRange(row, 1, 1, LOC_LOGOUT_COL + LOC_WIDTH - 1).getValues()[0];
    out.login = fmt_(r[3]);
    out.logout = fmt_(r[4]);
    out.hours = r[5] === '' ? '' : Number(r[5]).toFixed(2);
    out.hoursText = r[5] === '' ? '' : hm_(r[5]);
    out.state = r[4] ? 'done' : 'in';
    out.flags = [r[7], r[8]].filter(String).join(' | ');
    out.locIn = String(r[LOC_LOGIN_COL - 1 + 3] || '');
    out.locOut = String(r[LOC_LOGOUT_COL - 1 + 3] || '');
  }
  return out;
}

function markLogin(token) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const me = whoAmI_();
    const sheet = ss_().getSheetByName(LOG);
    ensureCols_(sheet);
    if (findRow_(sheet, todayKey_(), me.email) > 0) throw new Error('You have already logged in today.');

    const geo = readGeo_(token, me.email) || { status: 'none' };
    if (REQUIRE_LOCATION && geo.status !== 'ok') {
      throw new Error('Location is required. Tap the button again and allow location on the page that opens.');
    }

    const now = new Date();
    const limit = cfgValue_(2) * 60 + cfgValue_(4);
    const mins = minutesOfDay_(now);
    const late = mins > limit ? 'Late by ' + Math.round(mins - cfgValue_(2) * 60) + ' min' : '';
    const dayMode = dayModeFor_(now);
    const mode = modeFor_(geo, dayMode);
    sheet.appendRow([todayKey_(), me.email, me.name, now, '', '', '', late, '', 'Logged in', mode]);
    const row = sheet.getLastRow();
    sheet.getRange(row, 1).setNumberFormat('@').setValue(todayKey_());
    sheet.getRange(row, LOC_LOGIN_COL, 1, LOC_WIDTH).setValues([locCells_(geo, dayMode)]);
    removeGeo_(token);
  } finally {
    lock.releaseLock();
  }
  return getState();
}

function markLogout(note, token) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    const me = whoAmI_();
    const sheet = ss_().getSheetByName(LOG);
    ensureCols_(sheet);
    const row = findRow_(sheet, todayKey_(), me.email);
    if (row < 0) throw new Error('No login found for today. Log in first.');
    const r = sheet.getRange(row, 1, 1, 11).getValues()[0];
    if (r[4]) throw new Error('You have already logged out today.');

    const geo = readGeo_(token, me.email) || { status: 'none' };
    if (REQUIRE_LOCATION && geo.status !== 'ok') {
      throw new Error('Location is required. Tap the button again and allow location on the page that opens.');
    }

    const now = new Date();
    const hours = Math.round(((now - new Date(r[3])) / 3600000) * 100) / 100;
    const overtime = Math.max(0, Math.round((hours - cfgValue_(5)) * 100) / 100);
    const endMin = cfgValue_(3) * 60;
    const mins = minutesOfDay_(now);
    const early = mins < endMin ? 'Early by ' + Math.round(endMin - mins) + ' min' : '';

    const cleanNote = String(note || '').trim();
    if ((overtime > 0 || mins > endMin + NOTE_AFTER_MIN) && cleanNote.length < 15) {
      throw new Error('You are logging out past your shift. Add a short note (at least 15 characters) on what you worked on.');
    }

    sheet.getRange(row, 5, 1, 6).setValues([[now, hours, overtime, r[7], early, 'Complete']]);
    sheet.getRange(row, 12, 1, 2).setValues([[cleanNote, overtime > 0 ? 'Counted' : '']]);
    sheet.getRange(row, LOC_LOGOUT_COL, 1, LOC_WIDTH).setValues([locCells_(geo, dayModeFor_(now))]);
    sheet.getRange(row, DISP_COL, 1, 3).setValues([displayCells_(hours, overtime)]);
    removeGeo_(token);
  } finally {
    lock.releaseLock();
  }
  return getState();
}

function flagMissingLogouts() {
  const sheet = ss_().getSheetByName(LOG);
  const last = sheet.getLastRow();
  if (last < 2) return;
  const key = todayKey_();
  const vals = sheet.getRange(2, 1, last - 1, 10).getValues();
  vals.forEach((r, i) => {
    if (keyOf_(r[0]) < key && !r[4] && r[9] !== 'Missing logout') {
      sheet.getRange(i + 2, 10).setValue('Missing logout');
    }
  });
}
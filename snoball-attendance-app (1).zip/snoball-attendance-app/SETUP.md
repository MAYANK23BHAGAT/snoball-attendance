# Snoball Attendance app: setup

The app is a normal website (installable on both phones). Apps Script stays as the backend and still writes to your sheet.

## 1. Create the Google sign-in Client ID (one time)

1. Go to console.cloud.google.com and pick a project under the owledmedia.com organisation (or create one).
2. APIs & Services > OAuth consent screen. Choose user type **Internal**, so only owledmedia.com accounts can sign in. Fill the app name and your email, then save.
3. APIs & Services > Credentials > Create credentials > OAuth client ID > **Web application**.
4. Under Authorized JavaScript origins add the address where you will host the app, with no path and no trailing slash:
   - GitHub Pages: `https://mayank23bhagat.github.io`
   - Vercel: `https://your-project.vercel.app`
5. Create, then copy the **Client ID** (ends in `.apps.googleusercontent.com`).

## 2. Update Apps Script

1. In your Apps Script project add a new script file named `api` and paste everything from `backend/api.gs`.
2. In `api.gs`, replace `PASTE_CLIENT_ID.apps.googleusercontent.com` with your Client ID.
3. Replace everything in `Code.gs` with the contents of `backend/Code.gs`. It is your current code with two one-line changes (`whoAmI_` reads the app user, and `readGeo_` accepts location sent directly by the app). Nothing else changed.
4. Select the function `authorizeOnce` and click Run. Approve the new permission (external requests).
5. Deploy > Manage deployments > pencil on the **public** deployment (Execute as Me, access Anyone, the one whose URL is in `GEO_API_URL`) > Version: **New version** > Deploy. The URL stays the same.

## 3. Update the app and host it

1. Open `index.html` and replace `PASTE_CLIENT_ID.apps.googleusercontent.com` in `CONFIG` with the same Client ID. `API_URL` is already filled with your current `/exec` link.
2. Create a new public GitHub repo named `snoball-attendance`, upload `index.html`, `manifest.webmanifest`, `sw.js` and the `icons` folder, then turn on Pages (Settings > Pages > main, root). The `backend` folder is not needed there.
3. Make sure the hosting address matches what you added in step 1.4.

## 4. Test, then roll out

1. Open the hosted link on your phone, sign in with your OWLED account, and log in and out once. Check the Attendance Log row and location columns.
2. Install it:
   - Android: Chrome menu > Install app (or the Install button inside the app).
   - iPhone: Safari > Share > Add to Home Screen.
3. Teammates must be on the Team sheet. People stay signed in for 30 days.

## Notes

- The old Apps Script page and `location.html` keep working, so you can roll the new app out gradually.
- After any change to the Apps Script code, publish a new version of the deployment.
- If you ever change the hosting address, add the new one to Authorized JavaScript origins.
